module.exports = {
    type: 'postgres',
    host: 'localhost',
    port: 5432,
    username: 'postgres',
    password: '',
    database: 'BdPrueba',
    "synchronize": true,
    "logging": true,
    entities: ['dist/**/*.entity{.ts,.js}'],
    "cli": {
      "entitiesDir": "src/entities"
    }
  };
  