
// import { Injectable } from '@nestjs/common';
// import { InjectRepository } from '@nestjs/typeorm';
// import { Repository } from 'typeorm';
// import { User } from './user.entity';
// import { CreateUserDto, UpdateUserDto } from './dto';

// @Injectable()
// export class UsersService {
//   constructor(
//     @InjectRepository(User)
//     private readonly userRepository: Repository<User>,
//   ) {}

//   create(createUserDto: CreateUserDto) {
//     const user = this.userRepository.create(createUserDto);
//     return this.userRepository.save(user);
//   }

//   findAll() {
//     return this.userRepository.find();
//   }

//   findOne(id: number) {
//     return this.userRepository.findOne(id);
//   }

//   update(id: number, updateUserDto: UpdateUserDto) {
//     return this.userRepository.update(id, updateUserDto);
//   }

//   async remove(id: number) {
//     await this.userRepository.softDelete(id);
//     return true;
//   }
// }


import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  async create(user: Partial<User>): Promise<User> {
    const newUser = this.userRepository.create(user);
    return await this.userRepository.save(newUser);
  }

  async findAll(): Promise<User[]> {
    return await this.userRepository.find();
  }

  // Agrega funciones para editar, eliminar, etc.
}

