import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      // Configuración de TypeORM...
    }),
    UsersModule, // Otros módulos...
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {
  // No es necesario el constructor para habilitar CORS aquí

  // // Opcional: si necesitas configurar algo después de que el módulo se haya cargado, puedes usar el método `configure`
  // configure(consumer: MiddlewareConsumer) {
  //   // Configurar CORS aquí si es necesario
  //   consumer.apply(cors()).forRoutes('*');
  // }
}
