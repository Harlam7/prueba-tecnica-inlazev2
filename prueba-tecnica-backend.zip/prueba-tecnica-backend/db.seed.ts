// db.seed.ts
import { NestFactory } from '@nestjs/core';
// import { UserService } from './user.service';
import { AppModule } from 'src/app.module'; 
import { UserService } from 'src/users/users.service';
import { RoleService } from 'src/users/role.service';
import { User } from 'src/users/user.entity';
import { Role } from 'src/users/role.entity';

async function seed() {
  const app = await NestFactory.createApplicationContext(AppModule);

  const userService = app.get(UserService);
  const roleService = app.get(RoleService);

  // Crea roles de prueba
  const adminRole = await roleService.create({ name: 'admin', is_deleted: false });
  const userRole = await roleService.create({ name: 'user', is_deleted: false });

  // Crea usuarios de prueba asignando roles
  const adminUser = await userService.create({
    full_name: 'Admin User',
    email: 'admin@example.com',
    password: 'password123',
    phone: '123456789',
    role: adminRole.name,
    is_deleted: false,
  });

  const regularUser = await userService.create({
    full_name: 'Regular User',
    email: 'user@example.com',
    password: 'password456',
    phone: '987654321',
    role: userRole.name,
    is_deleted: false,
  });

  await app.close();
}

seed();
